﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prak_13._2
{
    class PC
    {
        private string cpu;
        private string gpu;
        private string mp;
        private string bp;
        private string cool_sis;
        private int coolers;
        private int chen;

        public PC(string cpu_, string gpu_, string mp_,string bp_, string cool_sis_,int coolers_,int chen_) 
        {
            this.cpu = cpu_;
            this.gpu = gpu_;
            this.mp = mp_;
            this.bp = bp_;
            this.cool_sis = cool_sis_;
            this.coolers = coolers_;
            this.chen = chen_;
        }
        public string get_cpu() 
        {
            return cpu;
        }
        public string get_gpu()
        {
            return gpu;
        }
        public string get_bp()
        {
            return bp;
        }
        public string get_mp()
        {
            return mp;
        }
        public string get_cool_sis()
        {
            return cool_sis;
        }
        public int get_coolers()
        {
            return coolers;
        }
        public void set_cpu(string text)
        {
            cpu = text;
        }
        public void set_gpu(string text)
        {
            gpu = text;
        }
        public void set_mp(string text)
        {
            mp = text;
        }
        public void set_bp(string text)
        {
            bp = text;
        }
        public void set_cool_sis(string text)
        {
            cool_sis = text;
        }
        public void set_coolers(int colv) 
        {
            coolers = colv;
        }
    }
}
