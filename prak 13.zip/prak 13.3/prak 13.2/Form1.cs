﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace prak_13._2
{
    public partial class Form1 : Form
    {
        private SortedDictionary<int,PC> setup = new SortedDictionary<int, PC>();
        private int num = 0;
        public Form1()
        {
            InitializeComponent();
            initDataGridView();
            processor.ContextMenuStrip = contextMenuStrip1;
            graphics_p.ContextMenuStrip = contextMenuStrip1;
            motherboard.ContextMenuStrip = contextMenuStrip1;
            power_unit.ContextMenuStrip = contextMenuStrip1;
            cooling.ContextMenuStrip = contextMenuStrip1;
            coolings.ContextMenuStrip = contextMenuStrip1;
            price.ContextMenuStrip = contextMenuStrip1;
            удалитьToolStripMenuItem.Click += удалитьToolStripMenuItem_Click;
        }
        private DataGridViewColumn processor = null;
        private DataGridViewColumn graphics_p= null;
        private DataGridViewColumn motherboard = null;
        private DataGridViewColumn power_unit = null;
        private DataGridViewColumn cooling = null;
        private DataGridViewColumn coolings = null;
        private DataGridViewColumn price = null;

        private void initDataGridView()
        {
            dataGridView1.DataSource = null;
            dataGridView1.Columns.Add(stolb_1());
            dataGridView1.Columns.Add(stolb_2());
            dataGridView1.Columns.Add(stolb_3());
            dataGridView1.Columns.Add(stolb_4());
            dataGridView1.Columns.Add(stolb_5());
            dataGridView1.Columns.Add(stolb_6());
            dataGridView1.Columns.Add(stolb_7());
            dataGridView1.AutoResizeColumns();
        }

        private DataGridViewColumn stolb_1()
        {
            if (processor == null)
            {
                processor = new DataGridViewTextBoxColumn();
                processor.Name = "";
                processor.HeaderText = "Процессор";
                processor.ValueType = typeof(string);
                processor.Width = dataGridView1.Width / 7;
            }
            return processor;
        }

        private DataGridViewColumn stolb_2()
        {
            if (graphics_p == null)
            {
                graphics_p = new DataGridViewTextBoxColumn();
                graphics_p.Name = "";
                graphics_p.HeaderText = "Видеокарта";
                graphics_p.ValueType = typeof(string);
                graphics_p.Width = dataGridView1.Width / 7;
            }
            return graphics_p;
        }

        private DataGridViewColumn stolb_3()
        {
            if (motherboard == null)
            {
                motherboard = new DataGridViewTextBoxColumn();
                motherboard.Name = "";
                motherboard.HeaderText = "Материнская плата";
                motherboard.ValueType = typeof(string);
                motherboard.Width = dataGridView1.Width / 7;
            }
            return motherboard;
        }
        private DataGridViewColumn stolb_4()
        {
            if (power_unit == null)
            {
                power_unit = new DataGridViewTextBoxColumn();
                power_unit.Name = "";
                power_unit.HeaderText = "Блок питания";
                power_unit.ValueType = typeof(string);
                power_unit.Width = dataGridView1.Width / 7;
            }
            return power_unit;
        }
        private DataGridViewColumn stolb_5()
        {
            if (cooling == null)
            {
                cooling = new DataGridViewTextBoxColumn();
                cooling.Name = "";
                cooling.HeaderText = "Охлаждение";
                cooling.ValueType = typeof(string);
                cooling.Width = dataGridView1.Width / 7;
            }
            return cooling;
        }
        private DataGridViewColumn stolb_6()
        {
            if (coolings == null)
            {
                coolings = new DataGridViewTextBoxColumn();
                coolings.Name = "";
                coolings.HeaderText = "кол-во куллеров";
                coolings.ValueType = typeof(string);
                coolings.Width = dataGridView1.Width / 7;
            }
            return coolings;
        }
        private DataGridViewColumn stolb_7()
        {
            if (price == null)
            {
                price = new DataGridViewTextBoxColumn();
                price.Name = "";
                price.HeaderText = "Цена";
                price.ValueType = typeof(string);
                price.Width = dataGridView1.Width / 7;
            }
            return price;
        }

        private void addStudent(string name, string surname, string recordBookNumber)
        {
            
        }

        private void deleteStudent(int elementIndex)
        {
            
        }
        private void showListInGrid() 
        {
            
        }

        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "" || comboBox2.Text == "" || comboBox3.Text == "" || comboBox4.Text == "" || comboBox5.Text == "")
            {
                MessageBox.Show("пустые строки");
            }
            else
            {
                schet(comboBox1.Text,comboBox2.Text,comboBox3.Text,comboBox4.Text,comboBox5.Text,Convert.ToInt32(numericUpDown1.Value));
            }
        }
        private int schet(string text1, string text2, string text3, string text4, string text5,int col_vo) 
        {
            int schet = 0;
            switch (text1) 
            {
                case "i3 - 10105f":
                    schet += 8500;
                    break;
                case "i5 - 10400f":
                    schet += 10500;
                    break;
                case "i7 - 10600k":
                    schet += 15000;
                    break;
                case "i9 - 11900kf":
                    schet += 26000;
                    break;
            }
            switch (text2)
            {
                case "RTX - 3060":
                    schet += 38000;
                    break;
                case "RTX -3070":
                    schet += 43000;
                    break;
                case "RTX - 4060":
                    schet += 39000;
                    break;
                case "RTX - 4070":
                    schet += 70000;
                    break;
            }
            switch (text3)
            {
                case "244x225":
                    schet += 8000;
                    break;
                case "305x330":
                    schet += 10000;
                    break;
            }
            switch (text4)
            {
                case "RTX - 3060":
                    schet += 38000;
                    break;
                case "RTX -3070":
                    schet += 43000;
                    break;
                case "RTX - 4060":
                    schet += 39000;
                    break;
                case "RTX - 4070":
                    schet += 70000;
                    break;
            }
            switch (text5) 
            {
                case "Воздушная":
                    schet += 4000;
                    break;
                case "Жидкостная":
                    schet +=10000;
                    break;
            }
            schet += (1000 * col_vo);
            PC sb = new PC(text1,text2,text3,text4,text5,col_vo,schet);
            SortedDictionary < int, PC > sbor = new SortedDictionary<int, PC> ();
            sbor.Add (0, sb);
            dataGridView1.Rows.Add (text1,text2,text3,text4,text5,col_vo,schet);
            return schet;
        }
        
        private void удалитьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear ();
        }

        private void сортировкаToolStripMenuItem_Click(object sender, EventArgs e)
        {
         
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
    }
}
